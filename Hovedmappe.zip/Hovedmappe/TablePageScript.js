// Declaring variables to reference the HTMl elements.
var homeSign = document.getElementById("homeImgDiv");
var txtMiddle = document.getElementById("txtMiddle");
var profileSign = document.getElementById("profileImgDiv");


// Click functions to the header elements to go into the other sites
homeSign.addEventListener("click", function(){

    setTimeout(function () {
        window.location.href = "index.html"; //will redirect to your blog page (an ex: blog.html)
     }, 1000);
});
txtMiddle.addEventListener("click", function(){

    setTimeout(function () {
        window.location.href = "CreateTable.html"; //will redirect to your blog page (an ex: blog.html)
     }, 1000);
});
profileSign.addEventListener("click", function(){

    setTimeout(function () {
        window.location.href = "TablePage.html"; //will redirect to your blog page (an ex: blog.html)
     }, 1000);
});

// init
let cardI = 0;
let orderI = 0;
let orderDrag;

// main container
const table = document.getElementById("container");
const body = document.body;

// newCardButton
const newCardButton = document.getElementById("newCardButtonContainer");
newCardButton.addEventListener("click", newCardPopUp);
const newCardPopContainer = document.getElementById("newCardPopContainer");
const popClose = document.getElementsByClassName("close")[0];
popClose.addEventListener("click", popDown);
const getCardName = document.getElementById("getCardName");
const popCardEnter = document.getElementById("cardEnter");
popCardEnter.addEventListener("click", createNewCard);

// open popup window for new card
function newCardPopUp(){
    newCardPopContainer.style.display = "block";
    getCardName.focus();
}

// close popup window for new card
function popDown(){
    newCardPopContainer.style.display = "none";
    getCardName.value = "";
}

function createNewCard(){
    cardGenerator();
    popDown();
}

// Creating new order
function createNewOrder(){
    
    const cardId = event.target.id.substr(event.target.id.length -1);
    const orderInput = document.getElementById("orderInput"+cardId);
    const currentCard = document.getElementById("card"+cardId);
    
    const order = document.createElement("div");
    order.className = "orders";
    order.id = "order"+orderI;
    order.draggable = "true";

    if(orderInput.value == ""){
        order.innerHTML = "New Order "+orderI;
    } if(orderInput.value != ""){
        order.innerHTML = orderInput.value;
    } 

    order.addEventListener("dragstart", dragStart);
    order.addEventListener("dragend", dragEnd);
    /* orderMove = document.querySelectorAll(".orders"); */
    
    currentCard.append(order);

    /* currentCard.append(document.getElementById("orderInputContainer"+cardId)); */

    orderI++;
    orderInput.value = "";
}

// Creating new cards
function cardGenerator(){
    if(cardI <= 4){
        
        const newCard = document.createElement("div");
        newCard.className = "cards";
        newCard.id = "card"+cardI;
        
        // checking for input, if no user input cardname = new card + cardI
        if(getCardName.value == ""){
            newCard.innerHTML = "New Card "+cardI;
        } if(getCardName.value != ""){
            newCard.innerHTML = getCardName.value;
        } 
        
        // Adding eventlistener for dragging to new cards
        newCard.addEventListener("dragover", dragOver);
        newCard.addEventListener("dragenter", dragEnter);
        newCard.addEventListener("dragleave", dragLeave);
        newCard.addEventListener("drop", dragDrop);
        table.append(newCard);

        // Edit button for cards
        const editCard = document.createElement("span");
        editCard.className = "edit";
        editCard.id = "cardEdit"+cardI;
        editCard.innerHTML = "&#9998;";
        editCard.addEventListener("click", editCardPop);
        newCard.append(editCard);

        // Order input init
        let orderInputContainer = document.createElement("div");
        orderInputContainer.className = "orderInputContainer";
        orderInputContainer.id = "orderInputContainer"+cardI;
        
        const orderEnter = document.createElement("span");
        orderEnter.className = "enter";
        orderEnter.id = "orderEnter"+cardI;
        orderEnter.innerHTML = "&plus;";
        orderEnter.addEventListener("click",createNewOrder);
        
        const getOrderName = document.createElement("input");
        getOrderName.className = "orderInput";
        getOrderName.id = "orderInput"+cardI;
        getOrderName.placeholder = "Enter new order name....";
        
        orderInputContainer.append(orderEnter);
        orderInputContainer.append(getOrderName);
        newCard.append(orderInputContainer);
        table.append(newCardButton);

        cardI++;

        // max cards
        if(cardI == 5){
            newCardButton.style.display = "none";
        }
    
    } else {
        alert("erroooor");
    }
}

function editCardPop(e){
    const cardId = e.target.id.substr(e.target.id.length -1);
    const currentCard = document.getElementById("card"+cardId);
    const editPop = document.createElement("div");
    editPop.className = "editPopContainer";
    editPop.style.display = "block";
    const editWindow = document.createElement("div");
    editWindow.className = "editPop";
    editWindow.innerHTML;
    editPop.append(editWindow);
    body.append(editPop);
    
    console.log(currentCard);
}

// Dragging
function dragStart(e){
    const target = getDiv (e.target);
    orderDrag = target;
    orderDrag.className += " hold";
    setTimeout(() => (this.className = "invisible"), 0);
}

function dragEnd(){
    this.className = "orders";
}

function dragOver(e){
    e.preventDefault();
    var target = getDiv (e.target);
    
    if(e.target.className == "orders"){
        var bounding = target.getBoundingClientRect();
        var offset = bounding.y + (bounding.height/2);
    }
    
    if ( e.clientY - offset > 0 && e.target.className !== "cards") {
       	target.style['border-bottom'] = 'solid 2px black';
        target.style['border-top'] = '';
    } else if ( e.clientY - offset < 0 && e.target.className != "cards") {
        target.style['border-top'] = 'solid 2px  black';
        target.style['border-bottom'] = '';
    }
}

function dragEnter(e){
    e.preventDefault();
    this.className += " .hovered";
}

function dragLeave(e){
    this.className = "cards";
    var target = getDiv(e.target);
    target.style['border-bottom'] = '';
    target.style['border-top'] = '';
    
}

function dragDrop(e){
    var target = getDiv( e.target );
    this.className = "cards";

    // check to place order above or below target
    if ( target.style['border-bottom'] !== '' && e.target.className !== "cards") {
        target.style['border-bottom'] = '';
        target.parentNode.insertBefore(orderDrag, e.target.nextSibling);
    } else if ( target.style['border-top'] !== '' && e.target.className !== "cards"){
        target.style['border-top'] = '';
        target.parentNode.insertBefore(orderDrag, e.target);
    } else if (e.target.className == "cards" ||  e.target.parentNode.className == "orderInputContainer" || e.target.className == "edit"){
        this.append(orderDrag);
    } else {
        alert("stupid");
    }
}

// get targeted div
function getDiv( target ) {
    while ( target.nodeName.toLowerCase() != 'div' && target.nodeName.toLowerCase() != 'body' && target.className.toLowerCase() != "cards" ) {
        target = target.parentNode;
    }
    if ( target.nodeName.toLowerCase() == 'body' ) {
        return false;
    } else {
        return target;
    }
}

